enum Emotion { kalem, senang, jahil, malu, kesal }

const _tags = {
  'kalem': Emotion.kalem,
  'senang': Emotion.senang,
  'jahil': Emotion.jahil,
  'malu': Emotion.malu,
  'kesal': Emotion.kesal,
};

class ParsedReply {
  const ParsedReply(this.emotion, this.text);

  /// Emosi dari tag di awal jawaban, atau null kalau belum ada / tidak ada.
  final Emotion? emotion;

  /// Isi jawaban tanpa tag.
  final String text;
}

/// Memisahkan tag emosi seperti "[senang]" di awal jawaban dari isi jawabannya.
/// Aman dipanggil berulang saat jawaban masih di-stream: selama tag belum
/// lengkap, teks dikembalikan kosong supaya tag setengah jadi tidak tampil.
ParsedReply parseReply(String raw) {
  var s = raw.trimLeft();
  Emotion? e;
  if (s.startsWith('[')) {
    final end = s.indexOf(']');
    if (end == -1) {
      return ParsedReply(null, s.length < 16 ? '' : s);
    }
    final tag = s.substring(1, end).toLowerCase().trim();
    final found = _tags[tag];
    if (found != null) {
      e = found;
      s = s.substring(end + 1).trimLeft();
    }
  }
  return ParsedReply(e, s);
}

/// Tebakan sederhana kalau model tidak memberi tag emosi.
Emotion guessEmotion(String text) {
  final s = text.toLowerCase();
  bool has(String pattern) => RegExp(pattern).hasMatch(s);
  if (has(r'wkwk|haha|hehe|iseng|jahil')) return Emotion.jahil;
  if (has(r'makasih|terima kasih|sayang|kangen|tersipu|malu')) return Emotion.malu;
  if (has(r'kesal|kesel|ngambek')) return Emotion.kesal;
  if (has(r'berhasil|mantap|keren|hore|yeay|selamat|bagus|semangat|asik')) {
    return Emotion.senang;
  }
  return Emotion.kalem;
}
