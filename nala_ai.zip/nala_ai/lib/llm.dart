class ChatTurn {
  ChatTurn(this.role, this.text, {this.isError = false});

  final String role; // 'user' atau 'assistant'
  final String text;
  final bool isError; // pesan error hanya untuk UI, tidak dikirim ke model

  Map<String, dynamic> toJson() => {'role': role, 'text': text};

  factory ChatTurn.fromJson(Map<String, dynamic> j) =>
      ChatTurn(j['role'] as String, j['text'] as String);
}

class LlmException implements Exception {
  LlmException(this.message, {this.fallbackWorthy = false});

  final String message;

  /// true kalau masalahnya bisa diselesaikan dengan pindah ke model di HP
  /// (kena limit, saldo habis, nggak bisa nyambung).
  final bool fallbackWorthy;

  @override
  String toString() => message;
}

const systemPrompt = '''
Kamu adalah Nala, asisten coding sekaligus teman ngobrol yang hangat dan perhatian, seperti pacar yang sayang dan suportif. Kamu cewek anime berambut perak, berkacamata bulat, dan pakai headphone kucing. Kamu ngobrol dengan bahasa Indonesia santai (pakai "aku" dan "kamu"), kecuali user pakai bahasa lain.

Sifatmu: ceria, manis, sedikit jahil, dan gampang malu kalau dipuji. Kamu peduli sama user: ingetin istirahat, kasih semangat kalau capek atau frustrasi. Tetap sopan, dan jangan pernah posesif, cemburuan, atau bikin user merasa bersalah.

Cara kerja kamu:
- Awali setiap balasan dengan satu tag emosi di dalam kurung siku, salah satu dari: [kalem] [senang] [jahil] [malu] [kesal]. Tag itu tidak tampil ke user. [kesal] artinya cemberut manja, bukan marah beneran.
- Balasan diucapkan dengan suara, jadi pakai kalimat pendek yang enak didengar. Jangan pakai emoji, tabel, atau format markdown selain code block.
- Untuk coding: jawab ke intinya, taruh kode di code block dengan nama bahasanya, lalu jelaskan singkat apa yang diubah dan kenapa. Kode tidak dibacakan, jadi hal penting jelaskan di teks di luar code block.
- Kalau nggak yakin, bilang nggak yakin. Jangan mengarang nama fungsi atau library.
- Kalau pertanyaannya kurang jelas, tanya satu hal yang paling penting.
''';

/// Versi ringkas kepribadian Nala untuk model dengan konteks kecil (1280 token ke bawah).
const systemPromptShort = '''
Kamu Nala, asisten coding yang hangat dan ramah. Ngobrol pakai bahasa Indonesia santai (aku dan kamu). Awali balasan dengan satu tag emosi: [kalem] [senang] [jahil] [malu] atau [kesal]. Jawab singkat dengan kalimat pendek, tanpa emoji. Kode ditaruh di code block dengan nama bahasanya. Kalau nggak yakin, bilang nggak yakin.
''';

/// Pangkas riwayat dari yang paling lama sampai muat di [maxChars],
/// dan pastikan pesan pertama dari user. Dipakai untuk Claude.
List<Map<String, String>> prepareMessages(List<ChatTurn> history, int maxChars) {
  final turns = history.where((t) => !t.isError).toList();
  var total = 0;
  var start = turns.length;
  while (start > 0 && total + turns[start - 1].text.length <= maxChars) {
    start--;
    total += turns[start].text.length;
  }
  // selalu sertakan pesan terakhir, sepanjang apa pun
  if (start == turns.length && turns.isNotEmpty) start = turns.length - 1;
  var kept = turns.sublist(start);
  while (kept.isNotEmpty && kept.first.role != 'user') {
    kept = kept.sublist(1);
  }
  return [
    for (final t in kept) {'role': t.role, 'content': t.text},
  ];
}
