import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppSettings {
  const AppSettings({
    this.engine = 'local',
    this.localModelId = 'gemma4',
    this.installedLocalId,
    this.claudeKey = '',
    this.claudeModel = 'claude-sonnet-5',
    this.useGpu = false,
    this.voiceOn = true,
    this.voiceRate = 0.5,
    this.voicePitch = 1.2,
  });

  /// 'local' (model di HP, gratis tanpa limit) atau 'claude'.
  final String engine;

  /// Model lokal yang dipilih di layar pengaturan.
  final String localModelId;

  /// Model lokal yang sudah terunduh dan terpasang (null = belum ada).
  final String? installedLocalId;

  final String claudeKey;
  final String claudeModel;
  final bool useGpu;

  /// Suara Nala.
  final bool voiceOn;
  final double voiceRate; // 0.3 sampai 0.7 (0.5 = normal)
  final double voicePitch; // 0.8 sampai 1.6

  bool get claudeReady => claudeKey.isNotEmpty;

  AppSettings copyWith({
    String? engine,
    String? localModelId,
    String? installedLocalId,
    bool clearInstalled = false,
    String? claudeKey,
    String? claudeModel,
    bool? useGpu,
    bool? voiceOn,
    double? voiceRate,
    double? voicePitch,
  }) =>
      AppSettings(
        engine: engine ?? this.engine,
        localModelId: localModelId ?? this.localModelId,
        installedLocalId:
            clearInstalled ? null : (installedLocalId ?? this.installedLocalId),
        claudeKey: claudeKey ?? this.claudeKey,
        claudeModel: claudeModel ?? this.claudeModel,
        useGpu: useGpu ?? this.useGpu,
        voiceOn: voiceOn ?? this.voiceOn,
        voiceRate: voiceRate ?? this.voiceRate,
        voicePitch: voicePitch ?? this.voicePitch,
      );
}

class SettingsStore {
  static const _secure = FlutterSecureStorage();
  static const _keyClaude = 'claude_key';
  static const _keyOld = 'anthropic_api_key'; // dari versi lama

  static Future<AppSettings> load() async {
    final p = await SharedPreferences.getInstance();
    final key = await _secure.read(key: _keyClaude) ??
        await _secure.read(key: _keyOld) ??
        '';
    return AppSettings(
      engine: p.getString('engine') ?? 'local',
      localModelId: p.getString('local_model') ?? 'gemma4',
      installedLocalId: p.getString('installed_local'),
      claudeKey: key,
      claudeModel: p.getString('claude_model') ?? 'claude-sonnet-5',
      useGpu: p.getBool('use_gpu') ?? false,
      voiceOn: p.getBool('voice_on') ?? true,
      voiceRate: p.getDouble('voice_rate') ?? 0.5,
      voicePitch: p.getDouble('voice_pitch') ?? 1.2,
    );
  }

  static Future<void> save(AppSettings s) async {
    final p = await SharedPreferences.getInstance();
    await p.setString('engine', s.engine);
    await p.setString('local_model', s.localModelId);
    if (s.installedLocalId == null) {
      await p.remove('installed_local');
    } else {
      await p.setString('installed_local', s.installedLocalId!);
    }
    await p.setString('claude_model', s.claudeModel);
    await p.setBool('use_gpu', s.useGpu);
    await p.setBool('voice_on', s.voiceOn);
    await p.setDouble('voice_rate', s.voiceRate);
    await p.setDouble('voice_pitch', s.voicePitch);
    await _secure.write(key: _keyClaude, value: s.claudeKey);
  }
}
