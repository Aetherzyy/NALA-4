import 'dart:io';

import 'package:flutter_gemma/flutter_gemma.dart';
import 'package:path_provider/path_provider.dart';

import 'llm.dart';

/// Konteks model (total token untuk riwayat + jawaban).
const _contextTokens = 4096;

/// Batas riwayat yang dikirim ke model di HP (karakter). Disisakan ruang
/// untuk jawaban di dalam konteks 4096 token.
const _historyChars = 4000;

class LocalModelSpec {
  const LocalModelSpec({
    required this.id,
    required this.name,
    required this.sizeLabel,
    required this.note,
    required this.url,
    required this.type,
    this.sizeMb,
  });

  final String id;
  final String name;
  final String sizeLabel;
  final String note;
  final String url;
  final ModelType type;

  /// Perkiraan ukuran file (MB) untuk mengecek unduhan lengkap atau tidak.
  final int? sizeMb;

  String get fileName => url.split('/').last;
}

const localModels = [
  LocalModelSpec(
    id: 'qwen3_fast',
    name: 'Qwen3 0.6B int4 (cepat)',
    sizeLabel: '0,3 GB',
    note:
        'Paling kecil dan cepat, tanpa mode "mikir". Coba ini dulu kalau model lain gagal dimuat.',
    url:
        'https://huggingface.co/litert-community/Qwen3-0.6B-int4/resolve/main/qwen3_0.6b_nothink_q4_block32_ekv1280.litertlm',
    type: ModelType.qwen3,
    sizeMb: 332,
  ),
  LocalModelSpec(
    id: 'qwen3_mixed',
    name: 'Qwen3 0.6B mixed int4',
    sizeLabel: '±0,4 GB',
    note: 'Varian lain Qwen3 kecil dengan format berbeda. Cadangan kalau yang lain gagal.',
    url:
        'https://huggingface.co/litert-community/Qwen3-0.6B/resolve/main/qwen3_0_6b_mixed_int4.litertlm',
    type: ModelType.qwen3,
  ),
  LocalModelSpec(
    id: 'qwen3',
    name: 'Qwen3 0.6B',
    sizeLabel: '0,6 GB',
    note: 'Versi INT8, sedikit lebih akurat tapi lebih berat.',
    url:
        'https://huggingface.co/litert-community/Qwen3-0.6B/resolve/main/Qwen3-0.6B.litertlm',
    type: ModelType.qwen3,
    sizeMb: 586,
  ),
  LocalModelSpec(
    id: 'gemma4',
    name: 'Gemma 4 E2B',
    sizeLabel: '2,6 GB',
    note:
        'Paling pintar dan paling teruji, tapi besar dan pelan di HP kelas menengah. Butuh penyimpanan lega (4 GB).',
    url:
        'https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm/resolve/main/gemma-4-E2B-it.litertlm',
    type: ModelType.gemma4,
    sizeMb: 2580,
  ),
];

LocalModelSpec? localModelById(String? id) {
  for (final m in localModels) {
    if (m.id == id) return m;
  }
  return null;
}

/// Model AI yang jalan langsung di HP. Setelah diunduh sekali, semuanya offline:
/// gratis, tanpa kuota, tanpa limit.
class LocalLlm {
  LocalLlm._();
  static final instance = LocalLlm._();

  dynamic _model;
  bool _modelGpu = true;

  /// Unduh dan pasang model. [onProgress] menerima 0 sampai 100.
  Future<void> install(
    LocalModelSpec spec, {
    required void Function(int percent) onProgress,
  }) async {
    await release();
    try {
      await FlutterGemma.installModel(
        modelType: spec.type,
        fileType: ModelFileType.litertlm,
      )
          .fromNetwork(spec.url, foreground: true)
          .withProgress((p) => onProgress(p))
          .install();
    } on DownloadException catch (e) {
      throw LlmException(e.error.toUserMessage());
    } catch (e) {
      throw LlmException('Gagal mengunduh model: $e');
    }
  }

  Future<void> uninstall(LocalModelSpec spec) async {
    await release();
    await FlutterGemma.uninstallModel(spec.fileName);
    await FlutterGemma.clearActiveInferenceIdentity();
  }

  /// Lepas model dari memori.
  Future<void> release() async {
    final m = _model;
    _model = null;
    if (m != null) {
      try {
        await m.close();
      } catch (_) {}
    }
  }

  int _ctx = _contextTokens;

  /// Batas riwayat (karakter) menyesuaikan ukuran konteks yang berhasil dimuat.
  int get _budget => ((_ctx - 900) * 2.5).round().clamp(600, _historyChars);

  String _short(Object e) {
    final s = e.toString().replaceAll('\n', ' ');
    return s.length > 400 ? '${s.substring(0, 400)}...' : s;
  }

  /// Cek file model di HP: ada atau tidak, dan ukurannya sesuai atau tidak.
  Future<String> _fileInfo(LocalModelSpec? spec) async {
    if (spec == null) return '';
    try {
      final dir = await getApplicationDocumentsDirectory();
      final f = File('${dir.path}/${spec.fileName}');
      if (!await f.exists()) {
        return 'File model TIDAK ditemukan di HP (${spec.fileName}). Hapus lalu unduh ulang.';
      }
      final mb = (await f.length()) / (1024 * 1024);
      final exp = spec.sizeMb;
      final verdict = exp == null
          ? ''
          : (mb < exp * 0.95
              ? ' (KURANG dari sekitar $exp MB: unduhan tidak lengkap, hapus lalu unduh ulang)'
              : ' (ukuran sesuai, sekitar $exp MB)');
      return 'File model di HP: ${mb.toStringAsFixed(0)} MB$verdict';
    } catch (_) {
      return '';
    }
  }

  /// Muat model. Kalau gagal, coba kombinasi lain: GPU lalu CPU, dan ukuran
  /// konteks 4096, 2048, 1280, lalu 1024. Semua alasan gagalnya dikumpulkan
  /// (dikelompokkan kalau sama) supaya penyebabnya bisa dilihat.
  Future<dynamic> _ensureModel(bool useGpu, LocalModelSpec? spec) async {
    if (_model != null && _modelGpu == useGpu) return _model;
    await release();
    final errors = <String, List<String>>{};
    for (final gpu in useGpu ? [true, false] : [false]) {
      for (final tokens in const [_contextTokens, 2048, 1280, 1024]) {
        try {
          _model = await FlutterGemma.getActiveModel(
            maxTokens: tokens,
            preferredBackend: gpu ? PreferredBackend.gpu : PreferredBackend.cpu,
          );
          _modelGpu = useGpu;
          _ctx = tokens;
          return _model;
        } catch (e) {
          errors
              .putIfAbsent(_short(e), () => [])
              .add('${gpu ? 'GPU' : 'CPU'} $tokens');
        }
      }
    }
    final info = await _fileInfo(spec);
    final detail = errors.entries
        .map((e) => '${e.value.join(', ')}:\n${e.key}')
        .join('\n\n');
    throw LlmException(
      'Model di HP gagal dimuat.\n'
      '${info.isEmpty ? '' : '$info\n'}'
      '\nCoba model lain di Pengaturan (mulai dari yang paling kecil), atau hapus lalu unduh ulang.\n\n'
      'Detail:\n$detail',
    );
  }

  /// Susun seluruh percakapan jadi satu prompt. Sengaja tanpa state di sisi
  /// model, jadi riwayat yang tersimpan tetap nyambung setelah app ditutup.
  String _buildPrompt(List<ChatTurn> history) {
    final turns = history.where((t) => !t.isError).toList();
    final lines = <String>[];
    var used = 0;
    for (var i = turns.length - 1; i >= 0; i--) {
      var text = turns[i].text;
      final label = turns[i].role == 'user' ? 'User' : 'Nala';
      final room = _budget - used;
      if (text.length > room) {
        if (lines.isNotEmpty) break;
        text = text.substring(text.length - room);
      }
      lines.add('$label: $text');
      used += text.length;
    }
    final sys = _ctx <= 1280 ? systemPromptShort : systemPrompt;
    return '$sys\n\n'
        'Percakapan sejauh ini:\n${lines.reversed.join('\n\n')}\n\n'
        'Tulis balasan Nala untuk pesan User yang terakhir. '
        'Mulai dengan satu tag emosi (misalnya [senang]), lalu langsung isi '
        'jawabannya, tanpa awalan "Nala:".';
  }

  Stream<String> stream(
    List<ChatTurn> history, {
    required bool useGpu,
    LocalModelSpec? spec,
  }) async* {
    final model = await _ensureModel(useGpu, spec);
    final chat = await model.openChat();
    var finished = false;
    try {
      await chat.addQueryChunk(
        Message.text(text: _buildPrompt(history), isUser: true),
      );
      await for (final r in chat.generateChatResponseAsync()) {
        if (r is TextResponse) yield r.token;
      }
      finished = true;
    } finally {
      if (!finished) {
        // dihentikan user: minta model berhenti menghasilkan token
        try {
          await (chat as dynamic).stopGeneration();
        } catch (_) {}
      }
      try {
        await chat.session.close();
      } catch (_) {}
    }
  }
}
