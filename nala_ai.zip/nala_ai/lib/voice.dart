import 'package:flutter/foundation.dart';
import 'package:flutter_tts/flutter_tts.dart';

/// Suara Nala. Jawaban yang masih di-stream dipotong per kalimat dan
/// diucapkan berurutan, jadi Nala mulai bicara sebelum jawabannya selesai.
/// Blok kode tidak dibacakan.
class NalaVoice {
  NalaVoice._();
  static final instance = NalaVoice._();

  final FlutterTts _tts = FlutterTts();

  /// true selama Nala sedang mengucapkan sesuatu (dipakai untuk gerak mulut).
  final ValueNotifier<bool> speaking = ValueNotifier(false);

  bool enabled = true;

  /// false kalau HP belum punya suara bahasa Indonesia.
  bool languageOk = true;

  bool _ready = false;
  final List<String> _queue = [];
  String _pending = '';
  bool _inCode = false;
  bool _announcedCode = false;
  bool _pumping = false;
  int _gen = 0;

  Future<void> init() async {
    if (_ready) return;
    _ready = true;
    try {
      await _tts.awaitSpeakCompletion(true);
      final r = await _tts.isLanguageAvailable('id-ID');
      languageOk = r == true || r == 1;
      await _tts.setLanguage('id-ID');
      await _tts.setVolume(1.0);
    } catch (_) {}
  }

  Future<void> configure({
    required bool enabled,
    required double rate,
    required double pitch,
  }) async {
    this.enabled = enabled;
    await init();
    try {
      await _tts.setSpeechRate(rate);
      await _tts.setPitch(pitch);
    } catch (_) {}
    if (!enabled) await stop();
  }

  /// Ucapkan contoh suara (dipakai di layar pengaturan).
  Future<void> test(double rate, double pitch) async {
    await init();
    await stop();
    try {
      await _tts.setSpeechRate(rate);
      await _tts.setPitch(pitch);
    } catch (_) {}
    _enqueue('Halo, aku Nala. Ini suaraku. Gimana, cocok nggak?');
  }

  /// Masukkan potongan teks baru dari jawaban yang sedang di-stream.
  void feed(String delta) {
    if (!enabled || delta.isEmpty) return;
    _pending += delta;
    _drain(finish: false);
  }

  /// Jawaban sudah selesai: ucapkan sisa teks yang belum terucap.
  void finish() {
    if (enabled) _drain(finish: true);
    _announcedCode = false;
  }

  Future<void> stop() async {
    _gen++;
    _queue.clear();
    _pending = '';
    _inCode = false;
    _announcedCode = false;
    _pumping = false;
    speaking.value = false;
    try {
      await _tts.stop();
    } catch (_) {}
  }

  // ---------- pemotongan kalimat ----------

  void _drain({required bool finish}) {
    while (true) {
      if (_inCode) {
        final i = _pending.indexOf('```');
        if (i == -1) {
          // buang isi kode; sisakan 2 karakter kalau pagar kode terpotong
          if (finish) {
            _pending = '';
          } else if (_pending.length > 2) {
            _pending = _pending.substring(_pending.length - 2);
          }
          return;
        }
        _pending = _pending.substring(i + 3);
        _inCode = false;
        continue;
      }
      final f = _pending.indexOf('```');
      if (f != -1) {
        _speakText(_pending.substring(0, f), all: true);
        _pending = _pending.substring(f + 3);
        _inCode = true;
        if (!_announcedCode) {
          _announcedCode = true;
          _enqueue('Kodenya aku taruh di layar ya.');
        }
        continue;
      }
      _pending = _speakText(_pending, all: finish);
      return;
    }
  }

  /// Ucapkan kalimat yang sudah lengkap, kembalikan sisa yang belum lengkap.
  String _speakText(String text, {required bool all}) {
    var start = 0;
    for (var i = 0; i < text.length; i++) {
      final c = text[i];
      final next = i + 1 < text.length ? text[i + 1] : null;
      final boundary = c == '!' ||
          c == '?' ||
          c == '\n' ||
          (c == '.' && next != null && (next == ' ' || next == '\n'));
      if (boundary && i + 1 - start >= 12) {
        _enqueue(text.substring(start, i + 1));
        start = i + 1;
      }
    }
    var rest = text.substring(start);
    if (!all && rest.length > 180) {
      final cut = rest.lastIndexOf(' ', 160);
      if (cut > 40) {
        _enqueue(rest.substring(0, cut));
        rest = rest.substring(cut + 1);
      }
    }
    if (all) {
      _enqueue(rest);
      return '';
    }
    return rest;
  }

  static final _url = RegExp(r'https?://\S+');
  static final _mdLink = RegExp(r'\[([^\]]*)\]\([^)]*\)');
  static final _emoji = RegExp(
    r'[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}\u{200D}]',
    unicode: true,
  );
  static final _mdChars = RegExp(r'[*#`>~|]');
  static final _spaces = RegExp(r'\s+');
  static final _hasText = RegExp(r'[A-Za-z0-9]');

  void _enqueue(String raw) {
    final clean = raw
        .replaceAll(_url, 'tautan')
        .replaceAllMapped(_mdLink, (m) => m[1] ?? '')
        .replaceAll(_emoji, '')
        .replaceAll(_mdChars, '')
        .replaceAll('_', ' ')
        .replaceAll(_spaces, ' ')
        .trim();
    if (!_hasText.hasMatch(clean)) return;
    _queue.add(clean);
    _ensurePump();
  }

  void _ensurePump() {
    if (_pumping) return;
    _pumping = true;
    _pump(_gen);
  }

  Future<void> _pump(int gen) async {
    speaking.value = true;
    try {
      while (gen == _gen && _queue.isNotEmpty) {
        final s = _queue.removeAt(0);
        try {
          await _tts.speak(s).timeout(const Duration(seconds: 45));
        } catch (_) {}
      }
    } finally {
      if (gen == _gen) {
        _pumping = false;
        speaking.value = false;
      }
    }
  }
}
